import { Component } from '@angular/core';
import { VaultService } from './services/vault.service';
import { GoogleAuthService } from './core/google/auth/google-auth.service';
import { GoogleSyncService } from './core/google/sync/google-sync.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {

  showVaultLock = false;

  constructor(
    public vaultService: VaultService,
    private googleAuthService: GoogleAuthService,
    private googleSyncService: GoogleSyncService
  ) {}

  ngOnInit() {

    // Phase 8: drain any queued uploads/deletes whenever connectivity
    // returns, regardless of which page is currently open.
    this.googleSyncService.startAutoSync();

    this.vaultService.onLockChange((locked) => {

      if (locked) {

        this.showVaultLock = true;

        setTimeout(() => {
          this.showVaultLock = false;
        }, 1600);
      }
    });
  }

  async logout() {

    await this.googleAuthService.signOut();

    window.location.href = '/login';

  }
}